# Boarding Buddy — Member 04 Frontend

Frontend prototype for:
- 5. Favourites
- 7. Messaging
- 8. Reviews & Ratings

## Run
This is a plain HTML/CSS/JavaScript frontend. No build tools are required.

1. Extract the ZIP.
2. Open `index.html` in a browser.

For the best local development workflow, open the folder in VS Code and use the Live Server extension.

## Important
This is a frontend demo. Data is stored in browser memory and resets on refresh. Messages are not delivered to real users. Reviews are not saved to a server, and booking eligibility is not verified. To make it production-ready, connect a backend API/database and implement authentication, authorization, real-time messaging, and server-side review eligibility checks.
