'use strict';

// Demo data. Replace this module with API calls when connecting a backend.
const properties = [
  {id:'green',name:'Green View Boarding',location:'Kadawela',price:18000,rating:4.5,reviews:23,amenities:['❄ AC','⌁ Wi-Fi','♨ Meals','♧ Laundry'],gradient:'linear-gradient(135deg,#c5dfd0,#7eaa8e 48%,#e5cda6)'},
  {id:'maple',name:'Maple Residence',location:'Kadawela',price:20000,rating:4.3,reviews:12,amenities:['❄ AC','⌁ Wi-Fi','♨ Meals'],gradient:'linear-gradient(135deg,#c9d9c7,#a4bca4 48%,#d6c09c)'},
  {id:'lodge',name:'University Lodge',location:'Kaduwela',price:22000,rating:4.7,reviews:18,amenities:['❄ AC','⌁ Wi-Fi','♧ Parking'],gradient:'linear-gradient(135deg,#c8d8df,#7197a2 48%,#d6c39f)'},
  {id:'sunshine',name:'Sunshine Hostel',location:'Kadawela',price:16000,rating:4.6,reviews:20,amenities:['⌁ Wi-Fi','♨ Meals','♧ Laundry'],gradient:'linear-gradient(135deg,#eed8b7,#d3a96f 48%,#a7c3a4)'}
];
let favourites = ['green','maple','sunshine'];
let selectedRating = 5;
let activeContact = 'green';
let helpfulVotes = 12;
let conversations = [
  {id:'green',name:'Green View Boarding',initials:'GV',owner:'Nimal Perera',unread:1,preview:'Yes, the room is available...',time:'10:24 AM',messages:[{mine:false,text:'Hi there! Thanks for your interest in Green View Boarding. How can I help you?',time:'10:20 AM'},{mine:true,text:'Hi! I wanted to ask if a single room is available for next month.',time:'10:22 AM'},{mine:false,text:'Yes, the room is available. Would you like to arrange a viewing this week?',time:'10:24 AM'}]},
  {id:'maple',name:'Maple Residence',initials:'MR',owner:'Kavindu Silva',unread:1,preview:'Thank you for your enquiry!',time:'Yesterday',messages:[{mine:false,text:'Hello! Thanks for contacting Maple Residence. What details would you like to know?',time:'Yesterday'},{mine:true,text:'Could you please share the monthly rent and facilities?',time:'Yesterday'},{mine:false,text:'Thank you for your enquiry! The monthly rent starts at LKR 20,000, including Wi-Fi.',time:'Yesterday'}]},
  {id:'lodge',name:'University Lodge',initials:'UL',owner:'Tharushi Fernando',unread:0,preview:'Can you share the check-in date?',time:'Mon',messages:[{mine:true,text:'Are there rooms available close to campus?',time:'Mon'},{mine:false,text:'We have a shared room available. Can you share your preferred check-in date?',time:'Mon'}]},
  {id:'sunshine',name:'Sunshine Hostel',initials:'SH',owner:'Hasini Jayawardena',unread:0,preview:'Your booking has been updated',time:'Sun',messages:[{mine:false,text:'Your booking enquiry has been updated. Let us know if you need anything else.',time:'Sun'}]}
];
let reviews = [
  {id:1,name:'Kasun Perera',initials:'KP',place:'University of Moratuwa',rating:5,title:'Great place! Very clean and friendly environment.',text:'Great place! Very clean and friendly environment. Highly recommend for students looking for a comfortable stay.',date:'2 days ago',sortDate:3,helpful:8,mine:false},
  {id:2,name:'Nimali Silva',initials:'NS',place:'University of Moratuwa',rating:4,title:'Good location and facilities',text:'Good location and facilities. The Wi-Fi could be better during the evening, but overall a comfortable place to stay.',date:'1 week ago',sortDate:2,helpful:4,mine:false},
  {id:3,name:'Ravindu Fernando',initials:'RF',place:'University of Moratuwa',rating:5,title:'Helpful owner and peaceful stay',text:'The owner was helpful throughout my stay and the area felt peaceful. The room was as described in the listing.',date:'2 weeks ago',sortDate:1,helpful:3,mine:false}
];
const $ = id => document.getElementById(id);
const money = n => 'LKR ' + n.toLocaleString('en-LK');
let toastTimer;
function toast(message) {
  const element = $('toast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove('show'), 2600);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
function propertyPhoto(property) {
  return `<div class="property-photo" style="background:${property.gradient}" aria-label="Illustration of ${escapeHtml(property.name)}"><div class="building"></div><div class="plant"></div></div>`;
}
function renderFavourites() {
  const query = $('favSearch').value.toLowerCase().trim();
  const saved = properties.filter(property => favourites.includes(property.id));
  $('favStat').textContent = saved.length;
  $('favNavCount').textContent = saved.length;
  $('favCountBadge').textContent = `${saved.length} saved`;
  $('avgRent').textContent = saved.length ? `LKR ${Math.round(saved.reduce((sum, property) => sum + property.price, 0) / saved.length / 1000)}k` : '—';
  const matches = saved.filter(property => `${property.name} ${property.location}`.toLowerCase().includes(query));
  $('favouriteList').innerHTML = matches.length ? matches.map(property => `
    <article class="boarding-card">
      ${propertyPhoto(property)}
      <div class="property-info"><h3>${escapeHtml(property.name)}</h3><div class="location">⌖ ${escapeHtml(property.location)}, Sri Lanka</div><div class="price">${money(property.price)}<span> / month</span></div><div class="rating">★ ${property.rating} <span>(${property.reviews} reviews)</span></div><div class="amenities">${property.amenities.map(item => `<span class="amenity">${escapeHtml(item)}</span>`).join('')}</div></div>
      <div class="card-actions"><button class="heart-btn" data-remove="${property.id}" title="Remove from favourites" aria-label="Remove ${escapeHtml(property.name)} from favourites">♥</button><button class="btn btn-primary" data-message-owner="${property.id}">Message owner</button><button class="btn btn-outline" data-property="${property.id}">View details</button></div>
    </article>`).join('') : `<div class="empty"><div class="big">♡</div><strong>${saved.length ? 'No saved boardings found' : 'No favourites saved yet'}</strong><p>${saved.length ? 'Try another search or browse available properties.' : 'Discover boardings and save the places you like.'}</p></div>`;
}
function renderContacts() {
  const query = $('contactSearch').value.toLowerCase().trim();
  const matches = conversations.filter(conversation => `${conversation.name} ${conversation.preview}`.toLowerCase().includes(query));
  $('contactsList').innerHTML = matches.length ? matches.map(conversation => `
    <button class="contact ${activeContact === conversation.id ? 'active' : ''}" data-contact="${conversation.id}">
      <div class="contact-avatar owner">${escapeHtml(conversation.initials)}</div><div class="contact-meta"><strong>${escapeHtml(conversation.name)}</strong><small>${escapeHtml(conversation.preview)}</small></div>
      <div class="contact-time">${escapeHtml(conversation.time)}${conversation.unread ? `<br><span class="unread-pill">${conversation.unread}</span>` : ''}</div>
    </button>`).join('') : '<div class="empty">No conversations match your search.</div>';
  $('unreadCount').textContent = conversations.reduce((sum, conversation) => sum + conversation.unread, 0);
  $('conversationCount').textContent = conversations.length;
}
function renderChat() {
  const conversation = conversations.find(item => item.id === activeContact) || conversations[0];
  if (!conversation) return;
  $('chatAvatar').textContent = conversation.initials;
  $('chatName').textContent = conversation.name;
  $('chatStatus').textContent = `${conversation.owner} · Owner`;
  const property = properties.find(item => item.id === conversation.id);
  $('chatProperty').textContent = property ? `${property.name} · ${money(property.price)}/mo` : 'Boarding enquiry';
  $('messagesArea').innerHTML = '<div class="day-divider">Conversation history</div>' + conversation.messages.map(message => `
    <div class="message ${message.mine ? 'mine' : ''}"><div class="bubble">${escapeHtml(message.text)}</div><time>${escapeHtml(message.time)}${message.mine ? ' · Sent' : ''}</time></div>`).join('');
  $('messagesArea').scrollTop = $('messagesArea').scrollHeight;
  conversation.unread = 0;
  renderContacts();
}
function renderReviews() {
  let list = [...reviews];
  const sort = $('reviewSort').value;
  if (sort === 'helpful') list.sort((a,b) => b.helpful - a.helpful);
  else if (sort === 'high') list.sort((a,b) => b.rating - a.rating || b.sortDate - a.sortDate);
  else list.sort((a,b) => b.sortDate - a.sortDate);
  $('reviewList').innerHTML = list.map(review => `
    <article class="panel review"><div class="review-top"><div class="reviewer">${escapeHtml(review.initials)}</div><div class="reviewer-meta"><strong>${escapeHtml(review.name)}</strong><small>${escapeHtml(review.place)} · ${escapeHtml(review.date)}</small></div><div class="review-stars" aria-label="${review.rating} out of 5 stars">${'★'.repeat(review.rating)}<span style="color:#dce7ed">${'★'.repeat(5-review.rating)}</span></div></div>
      <p><strong>${escapeHtml(review.title)}</strong><br>${escapeHtml(review.text)}</p><div class="review-foot"><span>Was this review helpful?</span><button class="helpful-btn" data-helpful="${review.id}">♡ Helpful (${review.helpful})</button></div></article>`).join('');
  $('myReviewCount').textContent = reviews.filter(review => review.mine).length;
  $('helpfulCount').textContent = helpfulVotes;
}
function setPage(page) {
  ['favourites','messaging','reviews'].forEach(name => { $('page-' + name).hidden = name !== page; });
  document.querySelectorAll('[data-page]').forEach(button => button.classList.toggle('active', button.dataset.page === page));
  const config = {
    favourites: {title:'Favourites',subtitle:'Your saved boarding places, all in one convenient shortlist.',crumb:'Favourites'},
    messaging: {title:'Messages',subtitle:'Talk directly with boarding owners and keep every detail in one place.',crumb:'Messaging'},
    reviews: {title:'Reviews & Ratings',subtitle:'Read student experiences and share a review of your stay.',crumb:'Reviews & Ratings'}
  };
  $('pageTitle').textContent = config[page].title;
  $('pageSubtitle').textContent = config[page].subtitle;
  $('breadcrumb').textContent = config[page].crumb;
  $('pageActions').innerHTML = page === 'favourites'
    ? '<button class="btn btn-outline" id="compareBtn">⇄ Compare saved</button><button class="btn btn-primary" id="browseBtn">＋ Find boardings</button>'
    : page === 'messaging'
      ? '<button class="btn btn-outline" id="markReadBtn">✓ Mark all read</button><button class="btn btn-primary" id="newMessageBtn">＋ New message</button>'
      : '<button class="btn btn-outline" id="reviewSortJump">↕ Sort reviews</button><button class="btn btn-primary" id="writeReviewBtn">✎ Write a review</button>';
  if (page === 'favourites') renderFavourites();
  if (page === 'messaging') { renderContacts(); renderChat(); }
  if (page === 'reviews') renderReviews();
}
function openConversation(propertyId) {
  let conversation = conversations.find(item => item.id === propertyId);
  if (!conversation) {
    const property = properties.find(item => item.id === propertyId);
    if (!property) return;
    conversation = {id:property.id,name:property.name,initials:property.name.split(' ').map(part => part[0]).slice(0,2).join(''),owner:'Property owner',unread:0,preview:'New conversation',time:'Now',messages:[{mine:false,text:'Hello! Thanks for reaching out. How can I help with your boarding enquiry?',time:'Now'}]};
    conversations.unshift(conversation);
  }
  activeContact = propertyId;
  setPage('messaging');
}
document.addEventListener('click', event => {
  const nav = event.target.closest('[data-page]');
  if (nav) { setPage(nav.dataset.page); return; }
  const remove = event.target.closest('[data-remove]');
  if (remove) { favourites = favourites.filter(id => id !== remove.dataset.remove); renderFavourites(); toast('Removed from favourites'); return; }
  const owner = event.target.closest('[data-message-owner]');
  if (owner) { openConversation(owner.dataset.messageOwner); toast('Conversation opened'); return; }
  const contact = event.target.closest('[data-contact]');
  if (contact) { activeContact = contact.dataset.contact; renderChat(); return; }
  const propertyButton = event.target.closest('[data-property]');
  if (propertyButton) { const property = properties.find(item => item.id === propertyButton.dataset.property); if (property) toast(`${property.name} · ${money(property.price)} per month`); return; }
  const star = event.target.closest('[data-star]');
  if (star) { selectedRating = Number(star.dataset.star); document.querySelectorAll('.star-pick').forEach(button => button.classList.toggle('on', Number(button.dataset.star) <= selectedRating)); return; }
  const helpful = event.target.closest('[data-helpful]');
  if (helpful) { const review = reviews.find(item => item.id === Number(helpful.dataset.helpful)); if (review) { review.helpful++; helpfulVotes++; renderReviews(); toast('Thanks for your feedback!'); } return; }
  const close = event.target.closest('[data-close]');
  if (close) { $(close.dataset.close).classList.remove('open'); return; }
  if (event.target.id === 'writeReviewBtn') { $('reviewModal').classList.add('open'); return; }
  if (event.target.id === 'newMessageBtn') { $('newMessageModal').classList.add('open'); return; }
  if (event.target.id === 'markReadBtn') { conversations.forEach(conversation => conversation.unread = 0); renderContacts(); toast('All conversations marked as read'); return; }
  if (event.target.id === 'browseBtn' || event.target.id === 'discoverBtn') { toast('Connect the Browse Boardings page to continue'); return; }
  if (event.target.id === 'compareBtn') { const saved = properties.filter(property => favourites.includes(property.id)); toast(saved.length ? `Saved rent range: ${money(Math.min(...saved.map(property => property.price)))} – ${money(Math.max(...saved.map(property => property.price)))} / month` : 'Save boardings to compare'); return; }
  if (event.target.id === 'reviewSortJump') { $('reviewSort').focus(); return; }
  if (event.target.id === 'helpBtn' || event.target.id === 'settingsBtn') { toast('This section can be connected to your full application'); return; }
  if (event.target.classList.contains('modal-backdrop')) event.target.classList.remove('open');
});
$('favSearch').addEventListener('input', renderFavourites);
$('contactSearch').addEventListener('input', renderContacts);
$('reviewSort').addEventListener('change', renderReviews);
$('clearFavSearch').addEventListener('click', () => { $('favSearch').value = ''; renderFavourites(); });
$('messageForm').addEventListener('submit', event => {
  event.preventDefault();
  const input = $('messageInput');
  const text = input.value.trim();
  if (!text) return;
  const conversation = conversations.find(item => item.id === activeContact);
  if (!conversation) return;
  const time = new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
  conversation.messages.push({mine:true,text,time});
  conversation.preview = text;
  conversation.time = 'Now';
  input.value = '';
  renderChat();
  toast('Message added to this demo');
});
$('reviewForm').addEventListener('submit', event => {
  event.preventDefault();
  if (!$('verifiedCheck').checked) { toast('Please confirm your review is genuine'); return; }
  const title = $('reviewTitle').value.trim();
  const text = $('reviewText').value.trim();
  if (text.length < 15) { toast('Please write at least 15 characters'); return; }
  reviews.unshift({id:Date.now(),name:'You',initials:'YO',place:$('reviewProperty').value,rating:selectedRating,title,text,date:'Just now',sortDate:Date.now(),helpful:0,mine:true});
  $('reviewForm').reset();
  selectedRating = 5;
  document.querySelectorAll('.star-pick').forEach(button => button.classList.add('on'));
  $('reviewModal').classList.remove('open');
  setPage('reviews');
  toast('Review added to this preview');
});
$('newMessageForm').addEventListener('submit', event => {
  event.preventDefault();
  const propertyId = $('ownerSelect').value;
  const text = $('firstMessage').value.trim();
  if (!text) return;
  let conversation = conversations.find(item => item.id === propertyId);
  if (!conversation) {
    const property = properties.find(item => item.id === propertyId);
    conversation = {id:property.id,name:property.name,initials:property.name.split(' ').map(part => part[0]).slice(0,2).join(''),owner:'Property owner',unread:0,preview:'',time:'Now',messages:[]};
    conversations.unshift(conversation);
  }
  conversation.messages.push({mine:true,text,time:'Now'});
  conversation.preview = text;
  conversation.time = 'Now';
  activeContact = propertyId;
  $('newMessageForm').reset();
  $('newMessageModal').classList.remove('open');
  setPage('messaging');
  toast('Enquiry added to this demo');
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') document.querySelectorAll('.modal-backdrop.open').forEach(modal => modal.classList.remove('open'));
});
setPage('messaging');
